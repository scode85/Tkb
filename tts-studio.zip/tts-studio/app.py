#!/usr/bin/env python3
"""TTS Studio - SRT to Audio. No auth, no limits."""
import os, sys, uuid, time, threading, traceback
from pathlib import Path

BASE = Path(__file__).parent.resolve()
sys.path.insert(0, str(BASE))

from flask import Flask, request, render_template, jsonify, send_file, abort
from werkzeug.utils import secure_filename

import dubber
import nghi_sherpa

UPLOAD_DIR = BASE / "uploads"
OUTPUT_DIR = BASE / "outputs"
UPLOAD_DIR.mkdir(exist_ok=True)
OUTPUT_DIR.mkdir(exist_ok=True)

MAX_SIZE_MB = 500
MAX_SIZE = MAX_SIZE_MB * 1024 * 1024

JOBS = {}
JOBS_LOCK = threading.Lock()
TTS_RUN_LOCK = threading.Lock()

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = MAX_SIZE
app.config['SECRET_KEY'] = 'tts-studio-' + uuid.uuid4().hex[:8]


def _run_tts(job_id, srt_path, voice, speed, batch_size):
    def up(**kw):
        with JOBS_LOCK:
            if job_id in JOBS:
                JOBS[job_id].update(kw)

    with TTS_RUN_LOCK:
        try:
            up(status='processing', progress=2)
            out_dir = OUTPUT_DIR / ('tts_' + job_id)

            def on_progress(c, t):
                if t > 0:
                    pct = 2 + int(93 * c / t)
                    up(progress=pct, current=c, total=t)

            audio = dubber.dub_srt(
                srt_path, out_dir, 'vi', voice,
                progress_cb=on_progress,
                concurrency=8, speed=speed,
                batch_size=batch_size,
            )
            up(status='done', progress=100, file=str(audio))
            print('[DONE] ' + job_id + ' -> ' + str(audio))
        except Exception as e:
            tb = traceback.format_exc()
            print('[ERROR] ' + job_id)
            print(tb)
            up(status='error', error=str(e)[:500])
        finally:
            try:
                srt_path.unlink(missing_ok=True)
            except Exception:
                pass


@app.route('/')
def index():
    return render_template(
        'index.html',
        voices=dubber.VOICES.get('vi', []),
        labels=dubber.VOICE_LABELS,
        pool_size=nghi_sherpa.POOL_SIZE,
        cpu=nghi_sherpa._CPU_COUNT,
        threads=nghi_sherpa._THREADS_PER_INSTANCE,
    )


@app.route('/api/config')
def api_config():
    return jsonify({
        'pool_size': nghi_sherpa.POOL_SIZE,
        'cpu': nghi_sherpa._CPU_COUNT,
        'threads': nghi_sherpa._THREADS_PER_INSTANCE,
        'max_size_mb': MAX_SIZE_MB,
    })


@app.route('/api/tts', methods=['POST'])
def api_tts():
    if 'srt' not in request.files:
        return jsonify({'error': 'Chua chon file SRT'}), 400
    f = request.files['srt']
    if not f.filename or not f.filename.lower().endswith('.srt'):
        return jsonify({'error': 'Chi nhan file .srt'}), 400

    voice = request.form.get('voice', 'nghi:ngochuyen')
    try:
        speed = float(request.form.get('speed', '1.0'))
        speed = max(0.5, min(2.0, speed))
    except Exception:
        speed = 1.0
    try:
        batch_size = int(request.form.get('batch_size', '50'))
        batch_size = max(10, min(200, batch_size))
    except Exception:
        batch_size = 50

    job_id = uuid.uuid4().hex[:12]
    srt_path = UPLOAD_DIR / ('tts_' + job_id + '.srt')
    f.save(str(srt_path))

    if srt_path.stat().st_size == 0:
        return jsonify({'error': 'File rong'}), 400

    with JOBS_LOCK:
        JOBS[job_id] = {
            'status': 'queued', 'progress': 0,
            'current': 0, 'total': 0,
            'error': None, 'file': None,
            'voice': voice, 'speed': speed,
            'created_at': time.time(),
            'filename': secure_filename(f.filename),
        }

    threading.Thread(
        target=_run_tts,
        args=(job_id, srt_path, voice, speed, batch_size),
        daemon=True,
    ).start()

    return jsonify({'job_id': job_id})


@app.route('/api/status/<job_id>')
def api_status(job_id):
    with JOBS_LOCK:
        j = JOBS.get(job_id)
    if not j:
        return jsonify({'error': 'Khong tim thay'}), 404
    elapsed = time.time() - j.get('created_at', time.time())
    return jsonify({
        'status': j['status'],
        'progress': j.get('progress', 0),
        'current': j.get('current', 0),
        'total': j.get('total', 0),
        'error': j.get('error'),
        'elapsed': round(elapsed, 1),
        'filename': j.get('filename'),
    })


@app.route('/api/download/<job_id>')
def api_download(job_id):
    with JOBS_LOCK:
        j = JOBS.get(job_id)
    if not j or not j.get('file'):
        abort(404)
    fp = Path(j['file'])
    if not fp.exists():
        abort(404)
    name = Path(j.get('filename') or job_id).stem + '_audio.mp3'
    return send_file(str(fp), as_attachment=True,
                     download_name=name, mimetype='audio/mpeg',
                     conditional=True)


@app.route('/api/download_srt/<job_id>')
def api_download_srt(job_id):
    with JOBS_LOCK:
        j = JOBS.get(job_id)
    if not j or not j.get('file'):
        abort(404)
    fp = Path(j['file']).parent / 'synced.srt'
    if not fp.exists():
        abort(404)
    name = Path(j.get('filename') or job_id).stem + '_synced.srt'
    return send_file(str(fp), as_attachment=True,
                     download_name=name,
                     mimetype='application/x-subrip',
                     conditional=True)


@app.route('/api/preview/<job_id>')
def api_preview(job_id):
    with JOBS_LOCK:
        j = JOBS.get(job_id)
    if not j or not j.get('file'):
        abort(404)
    fp = Path(j['file'])
    if not fp.exists():
        abort(404)
    return send_file(str(fp), mimetype='audio/mpeg', conditional=True)


if __name__ == '__main__':
    port = int(os.environ.get('TTS_PORT', '5001'))
    host = os.environ.get('TTS_HOST', '0.0.0.0')

    print('=' * 60)
    print('  TTS Studio - SRT to Audio')
    print('  Base:    ' + str(BASE))
    _cpu = getattr(nghi_sherpa, '_CPU_COUNT', 0) or __import__('os').cpu_count() or 4
    _pool = getattr(nghi_sherpa, 'POOL_SIZE', 1)
    _thr = getattr(nghi_sherpa, '_THREADS_PER_INSTANCE', 1)
    print('  CPU:     ' + str(_cpu) + ' core')
    print('  Pool:    ' + str(_pool) + ' instances')
    print('  Threads: ' + str(_thr) + '/instance')
    print('  Max:     ' + str(MAX_SIZE_MB) + ' MB')
    print('  Listen:  http://' + host + ':' + str(port))
    print('=' * 60)

    app.run(host=host, port=port, threaded=True, debug=False)
