"""
capcut_tts.py — Tích hợp CapCut TTS API (24 giọng Việt).
Cơ chế: submit task → poll mỗi 2s → download speech_url.
"""
import os
import re
import json
import time
import shutil
import subprocess
import urllib.request
from pathlib import Path

# ═══════════════════════════════════════════════════════════════
# 24 GIỌNG VIỆT CAPCUT
# ═══════════════════════════════════════════════════════════════
CAPCUT_VOICES_VI = [
    ('nho-ngot-ngao',       '🌸 Nhỏ Ngọt Ngào',       'BV421_vivn_streaming'),
    ('nu-pho-thong',        '🌸 Nữ Phổ Thông',        'vi_female_huong'),
    ('co-gai-hoat-ngon',    '🌸 Cô Gái Hoạt Ngôn',    'BV074_streaming'),
    ('giong-be',            '🌸 Giọng Bé',            'BV074_streaming_dsp'),
    ('mai',                 '🌸 Mai',                 'BV562_streaming'),
    ('ban-mai',             '🌸 Ban Mai',             'multi_female_yangguangnv_uranus_bigtts'),
    ('gai-moi-lon',         '🌸 Gái Mới Lớn',         'multi_female_peiqi_uranus_bigtts'),
    ('sunny-idol',          '🌸 Sunny Idol',          'multi_female_kiwi_uranus_bigtts'),
    ('review-phim-1',       '🌸 Review Phim 1',       'multi_female_richgirl_uranus_bigtts'),
    ('review-phim-2',       '🌸 Review Phim 2',       'multi_female_xyf04auto_uranus_bigtts'),
    ('review-phim-3',       '🌸 Review Phim 3',       'multi_female_daqi_uranus_bigtts'),
    ('review-phim-4',       '🌸 Review Phim 4',       'multi_female_stokie_uranus_bigtts'),
    ('ban-tin-nu-1',        '🌸 Bản Tin Nữ 1',        'multi_female_quanweinv_uranus_bigtts'),
    ('ban-tin-nu-2',        '🌸 Bản Tin Nữ 2',        'multi_female_sisi_uranus_bigtts'),
    ('ban-tin-nu-3',        '🌸 Bản Tin Nữ 3',        'multi_female_xinwenjieshuo_uranus_bigtts'),
    ('ban-tin-nu-4',        '🌸 Bản Tin Nữ 4',        'multi_female_tianmeijieshuo_uranus_bigtts'),
    ('nam-minh',            '🎙️ Nam Minh',            'vi-VN-NamMinhNeural'),
    ('nam-tram',            '🎙️ Nam Trầm',            'multi_male_felipe_uranus_bigtts'),
    ('thanh-nien-tu-tin',   '🎙️ Thanh Niên Tự Tin',   'BV075_streaming'),
    ('kenny-dai-de',        '🎙️ Kenny Đại Đế',        'BV075_streaming_demon_dsp'),
    ('viet-meo',            '🎙️ Việt Méo',            'BV075_streaming_vibrato_dsp'),
    ('robot-vn',            '🎙️ Robot VN',            'BV075_streaming_robot_dsp'),
    ('alex-dai-de',         '🎙️ Alex Đại Đế',         'BV560_streaming'),
    ('hoai-my',             '🌸 Hoài My (Edge)',      'vi-VN-HoaiMyNeural'),
]

CAPCUT_VOICE_MAP = {slug: vt for slug, _, vt in CAPCUT_VOICES_VI}
CAPCUT_VOICE_DISPLAY = {vt: label for _, label, vt in CAPCUT_VOICES_VI}


# ═══════════════════════════════════════════════════════════════
# HELPERS
# ═══════════════════════════════════════════════════════════════
def _find_capcut_cli():
    p = shutil.which('capcut-tts-api')
    if p:
        return p
    import sys
    candidates = [
        Path(sys.executable).parent / 'capcut-tts-api',
        Path.home() / '.local/bin/capcut-tts-api',
        Path('/data/data/com.termux/files/usr/bin/capcut-tts-api'),
    ]
    for c in candidates:
        if c.exists():
            return str(c)
    return None


def _parse_json_output(stdout):
    """CLI in '200\n{...json...}'. Tìm dòng JSON đầu tiên."""
    if not stdout:
        return None
    # Bỏ dòng status code nếu có
    for line in stdout.split('\n'):
        line = line.strip()
        if line.startswith('{'):
            try:
                return json.loads(line)
            except Exception:
                continue
    # Fallback: tìm bằng regex
    m = re.search(r'\{.*\}', stdout, re.DOTALL)
    if m:
        try:
            return json.loads(m.group(0))
        except Exception:
            pass
    return None


def _extract_task_info(data):
    """Lấy (task_id, token, status) từ response tts-new hoặc tts-query."""
    if not data:
        return None, None, None
    tasks = (data.get('data') or {}).get('tasks') or []
    if not tasks:
        return None, None, None
    t = tasks[0]
    return t.get('id'), t.get('token'), t.get('status', '')


def _extract_speech_url(data):
    """Lấy URL mp3 từ payload của task succeed."""
    if not data:
        return None
    tasks = (data.get('data') or {}).get('tasks') or []
    if not tasks:
        return None
    payload_str = tasks[0].get('payload') or ''
    if not payload_str:
        return None
    try:
        payload = json.loads(payload_str)
    except Exception:
        return None
    subs = payload.get('audio_subtitles') or []
    if not subs:
        return None
    return subs[0].get('speech_url')


def _normalize_audio(src, timeout=30):
    """
    Re-encode MP3 gốc sang MP3 chuẩn 44.1kHz stereo 128kbps
    với header Xing + ID3v2.3 để browser phát được.
    """
    src = Path(src)
    if not src.exists() or src.stat().st_size < 1000:
        return src
    tmp = src.with_suffix('.norm.mp3')
    try:
        r = subprocess.run([
            'ffmpeg', '-y', '-i', str(src),
            '-ar', '44100', '-ac', '2',
            '-c:a', 'libmp3lame', '-b:a', '128k',
            '-write_xing', '1',
            '-id3v2_version', '3',
            str(tmp)
        ], capture_output=True, timeout=timeout)
        if r.returncode == 0 and tmp.exists() and tmp.stat().st_size > 1000:
            src.unlink(missing_ok=True)
            return tmp
    except Exception as e:
        print(f"    ⚠️ normalize: {e}")
    if tmp.exists():
        tmp.unlink(missing_ok=True)
    return src


def _download(url, dest, timeout=30):
    """Download URL → MP3 → convert M4A. Trả về path file cuối."""
    dest = Path(dest)
    dest.parent.mkdir(parents=True, exist_ok=True)
    req = urllib.request.Request(
        url,
        headers={
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36',
            'Referer': 'https://www.capcut.com/',
        }
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            with open(dest, 'wb') as f:
                shutil.copyfileobj(resp, f)
    except Exception as e:
        print(f"    ⚠️ download: {e}")
        return None

    if not (dest.exists() and dest.stat().st_size > 1000):
        return None

    # Chuẩn hóa MP3
    final = _normalize_audio(dest)
    if final.exists() and final.stat().st_size > 1000:
        return final
    return None


# ═══════════════════════════════════════════════════════════════
# MAIN — SYNTHESIZE
# ═══════════════════════════════════════════════════════════════
def synthesize_capcut(text, output_file, voice_type,
                      timeout=60, poll_interval=2.0, speed=1.0):
    """
    TTS qua CapCut. Submit → poll → download.
    Trả về ('ok', None) | ('error', msg).
    """
    cli = _find_capcut_cli()
    if not cli:
        return ('error', 'Không tìm thấy CLI capcut-tts-api')

    if not text or not text.strip():
        return ('error', 'Text rỗng')

    out = Path(output_file)
    out.parent.mkdir(parents=True, exist_ok=True)
    if out.exists():
        out.unlink()

    # ── Bước 1: Submit ──
    cmd = [cli, 'tts-new', '--text', text[:5000], '--voice', voice_type]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
    except subprocess.TimeoutExpired:
        return ('error', 'Submit timeout')

    sub_data = _parse_json_output(r.stdout)
    task_id, token, _ = _extract_task_info(sub_data)
    if not task_id:
        err = (r.stderr or r.stdout or '')[-200:]
        return ('error', f'Submit fail: {err}')

    # ── Bước 2: Poll ──
    deadline = time.time() + timeout
    while time.time() < deadline:
        time.sleep(poll_interval)

        qcmd = [cli, 'tts-query', '--task-id', task_id, '--token', token]
        try:
            qr = subprocess.run(qcmd, capture_output=True, text=True, timeout=15)
        except subprocess.TimeoutExpired:
            continue

        q_data = _parse_json_output(qr.stdout)
        if not q_data:
            continue

        qtasks = (q_data.get('data') or {}).get('tasks') or []
        if not qtasks:
            continue

        status = qtasks[0].get('status', '')
        if status in ('succeed', 'success', 'done'):
            url = _extract_speech_url(q_data)
            if not url:
                return ('error', 'Task OK nhưng không có speech_url')

            # ── Bước 3: Download + chuẩn hóa MP3 ──
            tmp_mp3 = out.with_suffix('.tmp.mp3')
            final_file = _download(url, tmp_mp3)
            if final_file and final_file.exists():
                # Rename về đúng output_file (.mp3)
                if final_file != out:
                    if out.exists():
                        out.unlink()
                    try:
                        final_file.rename(out)
                    except Exception:
                        import shutil as _sh
                        _sh.copy(str(final_file), str(out))
                        final_file.unlink(missing_ok=True)
                if out.exists() and out.stat().st_size > 1000:
                    # Kiểm tra volume — file silent là lỗi
                    try:
                        r = subprocess.run(
                            ['ffmpeg', '-i', str(out), '-af', 'volumedetect',
                             '-f', 'null', '-'],
                            capture_output=True, text=True, timeout=20)
                        import re as _re
                        m = _re.search(r'mean_volume:\s*([-\d.]+)', r.stderr)
                        if m:
                            mean_db = float(m.group(1))
                            if mean_db < -60:
                                print(f"    ⚠️ CapCut trả file silent ({mean_db}dB)")
                                return ('error', f'CapCut silent ({mean_db}dB)')
                    except Exception:
                        pass
                    return ('ok', None)
            return ('error', 'Download audio fail')

        if status in ('failed', 'fail', 'error'):
            msg = qtasks[0].get('msg', 'unknown')
            return ('error', f'CapCut task failed: {msg}')

    return ('error', f'CapCut timeout sau {timeout}s')


def capcut_voice_exists(slug_or_type):
    return slug_or_type in CAPCUT_VOICE_MAP or slug_or_type in CAPCUT_VOICE_DISPLAY


def capcut_available():
    return _find_capcut_cli() is not None
