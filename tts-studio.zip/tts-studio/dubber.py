import asyncio, subprocess, os, threading, shutil, re
import capcut_tts
try:
    import nghi_sherpa
except ImportError:
    nghi_sherpa = None
import srt
from pathlib import Path

# ============================================================
# DANH SÁCH GIỌNG ĐỌC
# ============================================================
VOICES = {
    'vi': [
        'nghi:banmai',         'nghi:ngocngan',
        'nghi:maiphuong',      'nghi:minhthu',
        'nghi:mytam',          'nghi:mytam2',
        'nghi:ngochuyen',      'nghi:ngochuyennew',
        'nghi:phuongtrang',    'nghi:thanhphuong2',
        'nghi:vietthao',       'nghi:yannew',
        'nghi:lacphi',         'nghi:chieuthanh',
        'nghi:calmwoman',      'nghi:adam1',
        'nghi:manhdung',       'nghi:minhkhang',
        'nghi:minhquang',      'nghi:deepman',
        'nghi:duyoryx',        'nghi:taian2',
        'nghi:taian4',         'nghi:tranthanh',
        'nghi:thientam',
        'capcut:ban-tin-nu-1',    'capcut:ban-tin-nu-2',
        'capcut:ban-tin-nu-3',    'capcut:ban-tin-nu-4',
        'capcut:nho-ngot-ngao',   'capcut:nu-pho-thong',
        'capcut:co-gai-hoat-ngon','capcut:giong-be',
        'capcut:mai',             'capcut:ban-mai',
        'capcut:gai-moi-lon',     'capcut:sunny-idol',
        'capcut:review-phim-1',   'capcut:review-phim-2',
        'capcut:review-phim-3',   'capcut:review-phim-4',
        'capcut:nam-minh',        'capcut:nam-tram',
        'capcut:thanh-nien-tu-tin','capcut:kenny-dai-de',
        'capcut:viet-meo',        'capcut:robot-vn',
        'capcut:alex-dai-de',
        'vi-VN-HoaiMyNeural', 'vi-VN-NamMinhNeural',
        'hfspace:vieneu-v3-turbo:ngoc-huyen',
        'hfspace:vieneu-v3-turbo:minh-quan-pro',
        'hfspace:vieneu-v3-turbo:adam-bua',
        'hfspace:vieneu-v3-turbo:truc-ly',
        'hfspace:vieneu-v3-turbo:anh-khoi',
        'hfspace:vieneu-v3-turbo:mai-anh',
        'hfspace:vieneu-v3-turbo:thuy-dung',
        'hfspace:vieneu-v3-turbo:thien-tam-duc',
        'hfspace:vieneu-v3-turbo:quang-son',
        'hfspace:vieneu-v3-turbo:ngoc-tran',
        'gtts:vi:com.vn:normal', 'gtts:vi:com.vn:slow',
    ],
    'en': [
        'en-US-AriaNeural', 'en-US-JennyNeural', 'en-US-GuyNeural',
        'en-US-AvaMultilingualNeural', 'en-US-AndrewMultilingualNeural',
        'en-GB-SoniaNeural', 'en-GB-RyanNeural',
        'gtts:en:com:normal', 'gtts:en:co.uk:normal', 'gtts:en:com.au:normal',
    ],
    'zh': ['zh-CN-XiaoxiaoNeural', 'zh-CN-YunxiNeural', 'zh-CN-YunyangNeural',
           'gtts:zh:com:normal', 'gtts:zh:com.hk:normal'],
    'ja': ['ja-JP-NanamiNeural', 'ja-JP-KeitaNeural', 'gtts:ja:co.jp:normal'],
    'ko': ['ko-KR-SunHiNeural', 'ko-KR-InJoonNeural', 'gtts:ko:co.kr:normal'],
    'fr': ['fr-FR-DeniseNeural', 'fr-FR-HenriNeural', 'gtts:fr:fr:normal'],
    'es': ['es-ES-ElviraNeural', 'es-ES-AlvaroNeural',
           'gtts:es:es:normal', 'gtts:es:com.mx:normal'],
    'de': ['de-DE-KatjaNeural', 'de-DE-ConradNeural', 'gtts:de:de:normal'],
    'ru': ['ru-RU-SvetlanaNeural', 'ru-RU-DmitryNeural', 'gtts:ru:ru:normal'],
    'th': ['th-TH-PremwadeeNeural', 'th-TH-NiwatNeural', 'gtts:th:co.th:normal'],
    'hi': ['hi-IN-SwaraNeural', 'hi-IN-MadhurNeural', 'gtts:hi:co.in:normal'],
    'id': ['id-ID-GadisNeural', 'id-ID-ArdiNeural', 'gtts:id:co.id:normal'],
    'pt': ['pt-BR-FranciscaNeural', 'pt-BR-AntonioNeural', 'gtts:pt:com.br:normal'],
    'it': ['it-IT-ElsaNeural', 'it-IT-DiegoNeural', 'gtts:it:it:normal'],
    'ar': ['ar-SA-ZariyahNeural', 'ar-SA-HamedNeural', 'gtts:ar:com:normal'],
}

DEFAULT_VOICE = {k: v[0] for k, v in VOICES.items()}

def get_voices_for_lang(lang):
    return VOICES.get(lang, VOICES.get('en', []))


# ============================================================
# MAP FALLBACK — HF Space → Edge/gTTS
# ============================================================
EDGE_FALLBACK_MAP = {
    'ngoc-huyen':    'vi-VN-HoaiMyNeural',
    'minh-quan-pro': 'vi-VN-NamMinhNeural',
    'adam-bua':      'vi-VN-NamMinhNeural',
    'truc-ly':       'vi-VN-HoaiMyNeural',
    'anh-khoi':      'vi-VN-NamMinhNeural',
    'mai-anh':       'gtts:vi:com.vn:normal',
    'thuy-dung':     'gtts:vi:com.vn:normal',
    'thien-tam-duc': 'vi-VN-NamMinhNeural',
    'quang-son':     'vi-VN-NamMinhNeural',
    'ngoc-tran':     'vi-VN-HoaiMyNeural',
}


def get_edge_fallback(voice_id):
    if not voice_id:
        return 'vi-VN-HoaiMyNeural'
    parts = voice_id.split(':')
    if len(parts) >= 3:
        slug = parts[2]
        return EDGE_FALLBACK_MAP.get(slug, 'vi-VN-HoaiMyNeural')
    return 'vi-VN-HoaiMyNeural'


# Nhãn đẹp cho UI
VOICE_LABELS = {
    'nghi:banmai':         '🌸 Ban Mai',
    'nghi:ngocngan':       '🌸 Ngọc Ngân',
    'nghi:maiphuong':      '🌸 Mai Phương',
    'nghi:minhthu':        '🌸 Minh Thư',
    'nghi:mytam':          '🌸 Mỹ Tâm',
    'nghi:mytam2':         '🌸 Mỹ Tâm 2',
    'nghi:ngochuyen':      '🌸 Ngọc Huyền',
    'nghi:ngochuyennew':   '🌸 Ngọc Huyền (mới)',
    'nghi:phuongtrang':    '🌸 Phương Trang',
    'nghi:thanhphuong2':   '🌸 Thanh Phương',
    'nghi:vietthao':       '🌸 Việt Thảo',
    'nghi:yannew':         '🌸 Yan New',
    'nghi:lacphi':         '🌸 Lạc Phi',
    'nghi:chieuthanh':     '🌸 Chiêu Thanh',
    'nghi:calmwoman':      '🌸 Calm Woman',
    'nghi:adam1':          '🎙️ Adam',
    'nghi:manhdung':       '🎙️ Mạnh Dũng',
    'nghi:minhkhang':      '🎙️ Minh Khang',
    'nghi:minhquang':      '🎙️ Minh Quang',
    'nghi:deepman':        '🎙️ Deep Man',
    'nghi:duyoryx':        '🎙️ Duy Oryx',
    'nghi:taian2':         '🎙️ Tài An 2',
    'nghi:taian4':         '🎙️ Tài An 4',
    'nghi:tranthanh':      '🎙️ Trấn Thành',
    'nghi:thientam':       '🎙️ Thiền Tâm',
    'capcut:nho-ngot-ngao':       '🌸 Nhỏ Ngọt Ngào',
    'capcut:nu-pho-thong':        '🌸 Nữ Phổ Thông',
    'capcut:co-gai-hoat-ngon':    '🌸 Cô Gái Hoạt Ngôn',
    'capcut:giong-be':            '🌸 Giọng Bé',
    'capcut:mai':                 '🌸 Mai',
    'capcut:ban-mai':             '🌸 Ban Mai',
    'capcut:gai-moi-lon':         '🌸 Gái Mới Lớn',
    'capcut:sunny-idol':          '🌸 Sunny Idol',
    'capcut:review-phim-1':       '🌸 Review Phim 1',
    'capcut:review-phim-2':       '🌸 Review Phim 2',
    'capcut:review-phim-3':       '🌸 Review Phim 3',
    'capcut:review-phim-4':       '🌸 Review Phim 4',
    'capcut:ban-tin-nu-1':        '🌸 Bản Tin Nữ 1',
    'capcut:ban-tin-nu-2':        '🌸 Bản Tin Nữ 2',
    'capcut:ban-tin-nu-3':        '🌸 Bản Tin Nữ 3',
    'capcut:ban-tin-nu-4':        '🌸 Bản Tin Nữ 4',
    'capcut:nam-minh':            '🎙️ Nam Minh',
    'capcut:nam-tram':            '🎙️ Nam Trầm',
    'capcut:thanh-nien-tu-tin':   '🎙️ Thanh Niên Tự Tin',
    'capcut:kenny-dai-de':        '🎙️ Kenny Đại Đế',
    'capcut:viet-meo':            '🎙️ Việt Méo',
    'capcut:robot-vn':            '🎙️ Robot VN',
    'capcut:alex-dai-de':         '🎙️ Alex Đại Đế',
    'vi-VN-HoaiMyNeural':   '🌸 Hoài My (nữ, miền Nam)',
    'vi-VN-NamMinhNeural':  '🎙️ Nam Minh (nam, miền Bắc)',
    'en-US-AriaNeural':     '🌸 Aria (nữ, Mỹ)',
    'en-US-JennyNeural':    '🌸 Jenny (nữ, Mỹ)',
    'en-US-GuyNeural':      '🎙️ Guy (nam, Mỹ)',
    'en-US-AvaMultilingualNeural':    '🌸 Ava (đa ngôn ngữ)',
    'en-US-AndrewMultilingualNeural': '🎙️ Andrew (đa ngôn ngữ)',
    'en-GB-SoniaNeural':    '🌸 Sonia (nữ, Anh)',
    'en-GB-RyanNeural':     '🎙️ Ryan (nam, Anh)',
    'zh-CN-XiaoxiaoNeural': '🌸 Xiaoxiao',
    'zh-CN-YunxiNeural':    '🎙️ Yunxi',
    'zh-CN-YunyangNeural':  '🎙️ Yunyang',
    'ja-JP-NanamiNeural':   '🌸 Nanami',
    'ja-JP-KeitaNeural':    '🎙️ Keita',
    'ko-KR-SunHiNeural':    '🌸 SunHi',
    'ko-KR-InJoonNeural':   '🎙️ InJoon',
    'fr-FR-DeniseNeural':   '🌸 Denise',
    'fr-FR-HenriNeural':    '🎙️ Henri',
    'es-ES-ElviraNeural':   '🌸 Elvira',
    'es-ES-AlvaroNeural':   '🎙️ Alvaro',
    'de-DE-KatjaNeural':    '🌸 Katja',
    'de-DE-ConradNeural':   '🎙️ Conrad',
    'ru-RU-SvetlanaNeural': '🌸 Svetlana',
    'ru-RU-DmitryNeural':   '🎙️ Dmitry',
    'th-TH-PremwadeeNeural':'🌸 Premwadee',
    'th-TH-NiwatNeural':    '🎙️ Niwat',
    'hi-IN-SwaraNeural':    '🌸 Swara',
    'hi-IN-MadhurNeural':   '🎙️ Madhur',
    'id-ID-GadisNeural':    '🌸 Gadis',
    'id-ID-ArdiNeural':     '🎙️ Ardi',
    'pt-BR-FranciscaNeural':'🌸 Francisca',
    'pt-BR-AntonioNeural':  '🎙️ Antonio',
    'it-IT-ElsaNeural':     '🌸 Elsa',
    'it-IT-DiegoNeural':    '🎙️ Diego',
    'ar-SA-ZariyahNeural':  '🌸 Zariyah',
    'ar-SA-HamedNeural':    '🎙️ Hamed',
}


def pretty_voice(voice_id):
    if not voice_id:
        return '(không tên)'
    if voice_id in VOICE_LABELS:
        return VOICE_LABELS[voice_id]
    if voice_id.startswith('nghi:'):
        slug = voice_id.split(':', 1)[1]
        try:
            from piper_tts_custom import NGHI_VOICE_MAP
            label = NGHI_VOICE_MAP.get(slug)
            if label:
                return label
        except Exception:
            pass
        return f'🎙️ {slug.replace("-", " ").title()}'
    if voice_id.startswith('capcut:'):
        slug = voice_id.split(':', 1)[1]
        try:
            import capcut_tts as ct
            for s, label, _ in ct.CAPCUT_VOICES_VI:
                if s == slug:
                    return label
        except Exception:
            pass
        return f'🎙️ {slug.replace("-", " ").title()}'
    if voice_id.startswith('hfspace:'):
        parts = voice_id.split(':')
        if len(parts) >= 3:
            slug = parts[2]
            name = HF_VOICE_MAP.get(slug, slug.replace('-', ' ').title())
            return f'🤗 {name}'
        return '🤗 HF Space'
    if voice_id.startswith('gtts:'):
        parts = voice_id.split(':')
        lang = parts[1] if len(parts) > 1 else '?'
        tld = parts[2] if len(parts) > 2 else 'com'
        mode = parts[3] if len(parts) > 3 else 'normal'
        mode_str = 'chậm' if mode == 'slow' else 'thường'
        TLD_LABEL = {'com.vn': 'VN', 'com': 'US', 'com.au': 'AU',
                     'co.uk': 'UK', 'ca': 'CA'}
        region = TLD_LABEL.get(tld, tld)
        return f'🎵 gTTS [{region}] ({mode_str})'
    pretty = voice_id.replace('-Neural', '').replace('-', ' ').replace('_', ' ')
    return f'🔊 {pretty}'


HF_VOICE_MAP = {
    'ngoc-huyen':    'Ngọc Huyền',
    'minh-quan-pro': 'Minh Quân Pro',
    'adam-bua':      'Adam bựa',
    'truc-ly':       'Trúc Ly',
    'anh-khoi':      'Anh Khôi',
    'mai-anh':       'Mai Anh',
    'thuy-dung':     'Thùy Dung',
    'thien-tam-duc': 'Thiền Tâm Đức',
    'quang-son':     'Quang Sơn',
    'ngoc-tran':     'Ngọc Trân',
}


def parse_hfspace_voice(voice_id):
    if not voice_id:
        return 'Ngọc Huyền'
    parts = voice_id.split(':')
    if len(parts) >= 3:
        slug = parts[2]
        return HF_VOICE_MAP.get(slug, slug.replace('-', ' ').title())
    return 'Ngọc Huyền'


# ============================================================
# HUGGING FACE SPACE — VieNeu-TTS-v3-Turbo
# ============================================================
HF_SPACE_AVAILABLE = False
try:
    from gradio_client import Client, handle_file
    HF_SPACE_AVAILABLE = True
except ImportError:
    pass

_hf_client_instance = None
_hf_client_lock = threading.Lock()
_hf_config = None
_ref_audio_cache = {}
_ref_audio_lock = threading.Lock()


def get_hf_space_client():
    global _hf_client_instance
    if not HF_SPACE_AVAILABLE:
        return None
    if _hf_client_instance is not None:
        return _hf_client_instance
    with _hf_client_lock:
        if _hf_client_instance is not None:
            return _hf_client_instance
        hf_token = os.environ.get('HF_TOKEN', '').strip() or None
        if hf_token:
            print(f"🔌 HF Space với token ({hf_token[:8]}...)")
        else:
            print("🔌 HF Space (không có token → quota thấp)")

        attempts = []
        if hf_token:
            attempts += [{"hf_token": hf_token}, {"token": hf_token}]
        attempts += [{}]

        last_err = None
        for kwargs in attempts:
            try:
                _hf_client_instance = Client(
                    "pnnbao-ump/VieNeu-TTS-v3-Turbo", **kwargs)
                print(f"✅ Đã kết nối HF Space (kwargs={list(kwargs.keys())})")
                return _hf_client_instance
            except TypeError as e:
                last_err = e
                continue
            except Exception as e:
                print(f"⚠️  HF Space lỗi: {e}")
                _hf_client_instance = None
                return None

        print(f"⚠️  Không kết nối được HF Space: {last_err}")
        _hf_client_instance = None
        return _hf_client_instance


def _discover_hf_api():
    global _hf_config
    if _hf_config is not None:
        return _hf_config
    client = get_hf_space_client()
    if client is None:
        return None
    try:
        info = client.view_api(return_format="dict")
        named = info.get('named_endpoints', {})
        if not named:
            return None
        chosen = None
        if '/synthesize' in named:
            chosen = '/synthesize'
        else:
            for name in named.keys():
                if 'synthesize' in name.lower() or 'tts' in name.lower():
                    chosen = name
                    break
            if not chosen:
                for name in named.keys():
                    if not name.startswith('/_'):
                        chosen = name
                        break
            if not chosen:
                chosen = list(named.keys())[0]
        params = named[chosen].get('parameters', [])
        pnames = [p.get('parameter_name') or p.get('label', f'p{i}')
                  for i, p in enumerate(params)]
        print(f"✅ Endpoint: {chosen}")
        print(f"   Params: {pnames}")
        _hf_config = {'api_name': chosen, 'param_names': pnames, 'params_meta': params}
        return _hf_config
    except Exception as e:
        print(f"⚠️  Dò API lỗi: {e}")
        return None


def _get_ref_audio(voice_name="Ngọc Huyền"):
    cache_dir = Path.home() / ".cache" / "vieneu_refs"
    cache_dir.mkdir(parents=True, exist_ok=True)
    ref_file = cache_dir / "sample_ref.wav"

    if ref_file.exists() and ref_file.stat().st_size > 5000:
        return str(ref_file)

    with _ref_audio_lock:
        if ref_file.exists() and ref_file.stat().st_size > 5000:
            return str(ref_file)

        print("📥 Tạo sample_ref.wav (3s giọng Việt)...")
        try:
            import asyncio
            import edge_tts

            async def _make():
                c = edge_tts.Communicate(
                    "Xin chào, tôi là trợ lý ảo. Đây là giọng mẫu.",
                    "vi-VN-HoaiMyNeural")
                await c.save(str(ref_file.with_suffix('.mp3')))

            try:
                asyncio.run(_make())
            except RuntimeError:
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                loop.run_until_complete(_make())
                loop.close()

            mp3 = ref_file.with_suffix('.mp3')
            if mp3.exists() and mp3.stat().st_size > 1000:
                import subprocess
                r = subprocess.run([
                    'ffmpeg', '-y', '-i', str(mp3),
                    '-ar', '16000', '-ac', '1', '-t', '5',
                    str(ref_file)
                ], capture_output=True, timeout=30)
                mp3.unlink(missing_ok=True)
                if r.returncode == 0 and ref_file.exists():
                    print(f"✅ Đã tạo {ref_file} ({ref_file.stat().st_size} bytes)")
                    return str(ref_file)
        except Exception as e:
            print(f"⚠️ edge-tts fail: {e}")

        print("📥 Fallback: tải sample từ GitHub...")
        try:
            import urllib.request
            url = ("https://github.com/gradio-app/gradio/raw/main/"
                   "test/test_files/audio_sample.wav")
            urllib.request.urlretrieve(url, ref_file)
            if ref_file.exists() and ref_file.stat().st_size > 1000:
                print(f"✅ Đã tải {ref_file} ({ref_file.stat().st_size} bytes)")
                return str(ref_file)
        except Exception as e:
            print(f"⚠️ Tải sample fail: {e}")

        print(f"❌ Không tạo được ref_audio")
        return None


def synthesize_line_hf_space(text, output_file, voice_id=None):
    client = get_hf_space_client()
    if client is None:
        return ('error', 'HF Space chưa kết nối')

    config = _discover_hf_api()
    if config is None:
        return ('error', 'Không dò được API endpoint')

    voice_name = parse_hfspace_voice(voice_id)
    print(f"     HF voice: {voice_name}")

    ref_path = _get_ref_audio(voice_name)
    if ref_path is None:
        return ('error', f'Không có ref_audio cho "{voice_name}"')

    api_name = config['api_name']
    pnames = config['param_names']

    try:
        if 'ref_audio' in pnames:
            result = client.predict(
                text=text,
                voice=voice_name,
                ref_audio=handle_file(ref_path),
                temperature=0.8, top_k=25, top_p=0.95,
                repetition_penalty=1.2, max_new_frames=300, max_chars=256,
                api_name=api_name)
        else:
            kwargs = {}
            for pn in pnames:
                if 'text' in pn.lower():
                    kwargs[pn] = text
                elif 'voice' in pn.lower():
                    kwargs[pn] = voice_name
                elif 'ref' in pn.lower():
                    kwargs[pn] = handle_file(ref_path)
                else:
                    kwargs[pn] = None
            result = client.predict(**kwargs, api_name=api_name)
    except Exception as e:
        err_msg = str(e)
        if 'ZeroGPU' in err_msg or 'quota' in err_msg.lower():
            global _hf_client_instance
            with _hf_client_lock:
                _hf_client_instance = None
        return ('error', f'API lỗi: {err_msg}')

    audio_path = None
    if isinstance(result, tuple) and len(result) > 0:
        audio_path = result[0]
    elif isinstance(result, str):
        audio_path = result
    elif isinstance(result, dict):
        for v in result.values():
            if isinstance(v, str) and ('/' in v or v.endswith(('.wav', '.mp3'))):
                audio_path = v
                break
    elif hasattr(result, 'name'):
        audio_path = result.name

    if not audio_path or not Path(audio_path).exists():
        return ('error', f'Kết quả không hợp lệ: {result}')

    try:
        src_size = Path(audio_path).stat().st_size
        if src_size < 1000:
            return ('error', f'Audio HF Space quá nhỏ ({src_size} bytes)')
    except Exception:
        pass

    try:
        shutil.copy(audio_path, str(output_file))
        if not Path(output_file).exists() or Path(output_file).stat().st_size < 1000:
            return ('error', 'File copy rỗng')
    except Exception as e:
        return ('error', f'Copy lỗi: {e}')
    return ('ok', None)


# ============================================================
# EDGE-TTS + gTTS
# ============================================================
async def _edge_tts_one(text, voice, output_file, rate="+0%", pitch="+0Hz"):
    try:
        import edge_tts
        c = edge_tts.Communicate(text, voice, rate=rate, pitch=pitch)
        await c.save(str(output_file))
        return ('ok', None)
    except Exception as e:
        return ('error', str(e))


async def _edge_tts_batch(items, voice, rate, pitch):
    tasks = [_edge_tts_one(t, voice, o, rate, pitch) for t, o in items]
    return await asyncio.gather(*tasks)


def _gtts_one(text, lang, output_file, tld='com.vn', slow=False):
    try:
        from gtts import gTTS
        tts = gTTS(text=text, lang=lang, tld=tld, slow=slow)
        tts.save(str(output_file))
        return ('ok', None)
    except Exception as e:
        return ('error', str(e))


# ============================================================
# DISPATCH
# ============================================================
def synthesize_line_smart(text, voice, output_file,
                          rate="+0%", pitch="+0Hz", speed=1.0):
    # ── NGHI-TTS (Sherpa local) ──
    if voice.startswith('nghi:'):
        if nghi_sherpa is None:
            print("  ⚠️ nghi_sherpa chưa cài → fallback CapCut")
        else:
            slug = voice.split(':', 1)[1]
            status, result = nghi_sherpa.synthesize(text, output_file, slug)
            if status == 'ok':
                out = Path(output_file)
                if out.exists() and out.stat().st_size > 1000:
                    return ('ok', None)
            print(f"  ⚠️ NGHI fail ({result}) → fallback CapCut")

    # ── CapCut ──
    if voice.startswith('capcut:'):
        slug = voice.split(':', 1)[1]
        vt = capcut_tts.CAPCUT_VOICE_MAP.get(slug, slug)
        status, err = capcut_tts.synthesize_capcut(
            text, output_file, vt, timeout=60, speed=speed)
        out = Path(output_file)
        if status == 'ok' and out.exists():
            valid, reason = _check_audio_valid(out)
            if valid:
                return ('ok', None)
            print(f"  ⚠️ CapCut trả file lỗi ({reason})")
        print(f"  ⚠️ CapCut fail ({err}) → fallback Edge-TTS")
        out = Path(output_file)
        if out.exists():
            out.unlink(missing_ok=True)
        loop = asyncio.new_event_loop()
        try:
            asyncio.set_event_loop(loop)
            st, msg = loop.run_until_complete(
                _edge_tts_one(text, 'vi-VN-HoaiMyNeural', output_file))
        finally:
            loop.close()
        if st == 'ok':
            valid, reason = _check_audio_valid(output_file)
            if valid:
                return ('ok', None)
            return ('error', f'Edge-TTS trả file lỗi: {reason}')
        return (st, msg)

    # ── HF Space ──
    if voice.startswith('hfspace:'):
        status, err = synthesize_line_hf_space(text, output_file, voice_id=voice)
        out = Path(output_file)
        has_audio = out.exists() and out.stat().st_size > 1000

        if status == 'ok' and has_audio:
            return ('ok', None)

        print(f"  ⚠️ HF Space fail ({err}) → fallback Edge-TTS")
        if out.exists():
            out.unlink(missing_ok=True)

        fb_voice = get_edge_fallback(voice)
        print(f"  🔁 Fallback voice: {fb_voice}")

        st, msg = synthesize_line_smart(text, fb_voice, output_file,
                                        rate=rate, pitch=pitch)
        if st == 'ok' and out.exists() and out.stat().st_size > 1000:
            print(f"  ✅ Fallback OK ({fb_voice})")
            return ('ok', None)

        return ('error', f'Cả HF + fallback đều fail. HF: {err} | FB: {msg}')

    # ── gTTS ──
    if voice.startswith('gtts:'):
        parts = voice.split(':')
        lang = parts[1] if len(parts) > 1 else 'vi'
        tld = parts[2] if len(parts) > 2 else 'com.vn'
        slow = (parts[3] == 'slow') if len(parts) > 3 else False
        return _gtts_one(text, lang, output_file, tld=tld, slow=slow)

    # ── Edge-TTS trực tiếp ──
    loop = asyncio.new_event_loop()
    try:
        asyncio.set_event_loop(loop)
        result = loop.run_until_complete(
            _edge_tts_one(text, voice, output_file, rate=rate, pitch=pitch))
    finally:
        loop.close()
    return result


# ============================================================
# NATURAL SPEEDS — dãy tốc độ tự nhiên
# ============================================================
NATURAL_SPEEDS = [
    # Giảm tốc (hiếm dùng cho TTS)
    0.50, 0.60, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95,
    # Bình thường
    1.00,
    # Tăng tốc nhẹ — chi tiết 0.05
    1.05, 1.10, 1.15, 1.20, 1.25, 1.30, 1.35, 1.40, 1.45, 1.50,
    # Tăng tốc vừa — chi tiết 0.10
    1.60, 1.70, 1.80, 1.90, 2.00,
    # Tăng tốc mạnh
    2.20, 2.50, 2.80, 3.00,
    # Rất mạnh
    3.50, 4.00,
]


def _snap_speed(rate):
    """Snap rate về giá trị tự nhiên gần nhất.

    1.83 → 1.80 | 1.42 → 1.40 | 2.34 → 2.20
    """
    if rate <= 0:
        return 1.0
    return min(NATURAL_SPEEDS, key=lambda x: abs(x - rate))


# ============================================================
# AUDIO UTILS
# ============================================================
def _duration(audio_path):
    cmd = ['ffprobe', '-v', 'error', '-show_entries', 'format=duration',
           '-of', 'default=noprint_wrappers=1:nokey=1', str(audio_path)]
    r = subprocess.run(cmd, capture_output=True, text=True)
    try:
        return float(r.stdout.strip())
    except Exception:
        return 0.0



# ═══════════════════════════════════════════════════════════
# Dãy tốc độ tự nhiên chi tiết — dùng cho log cảnh báo
# (không snap trong tính toán để khớp mili giây)
# ═══════════════════════════════════════════════════════════
NATURAL_SPEEDS_DETAILED = [
    # Speed down rất chậm (ít dùng)
    0.50, 0.55, 0.60, 0.65, 0.70, 0.72, 0.75, 0.78, 0.80,
    # Speed down nhẹ
    0.82, 0.85, 0.88, 0.90, 0.92, 0.95, 0.97,
    # Bình thường
    1.00,
    # Speed up rất nhẹ (nghe không khác biệt)
    1.03, 1.05, 1.07, 1.10, 1.12, 1.15, 1.18, 1.20,
    # Speed up nhẹ
    1.22, 1.25, 1.27, 1.30, 1.32, 1.35, 1.38, 1.40,
    # Speed up vừa (nghe hơi nhanh)
    1.42, 1.45, 1.48, 1.50, 1.55, 1.60, 1.65, 1.70,
    # Speed up rõ (nghe nhanh)
    1.75, 1.80, 1.85, 1.90, 1.95, 2.00,
    # Speed up mạnh
    2.10, 2.20, 2.30, 2.40, 2.50, 2.60, 2.70, 2.80, 2.90, 3.00,
    # Cực mạnh
    3.20, 3.40, 3.60, 3.80, 4.00,
]


def _nearest_natural(rate):
    """Trả về tốc độ tự nhiên gần nhất (chỉ để log)."""
    return min(NATURAL_SPEEDS_DETAILED, key=lambda x: abs(x - rate))


def _atempo_chain(rate):
    """Chuỗi atempo filter — chain nếu rate > 2.0."""
    if abs(rate - 1.0) < 0.001:
        return 'anull'
    filters = []
    r = rate
    while r > 2.0:
        filters.append('atempo=2.0')
        r /= 2.0
    while r < 0.5:
        filters.append('atempo=0.5')
        r /= 0.5
    if abs(r - 1.0) > 0.001:
        filters.append(f'atempo={r:.3f}')
    return ','.join(filters) if filters else 'anull'


def _trim_silence(src, dst, threshold='-40dB', min_sil=0.15):
    """Trim silence đầu và cuối audio."""
    cmd = [
        'ffmpeg', '-y', '-i', str(src),
        '-af',
        f'silenceremove='
        f'start_periods=1:'
        f'start_silence=0:'
        f'start_threshold={threshold}:'
        f'stop_periods=-1:'
        f'stop_duration={min_sil}:'
        f'stop_threshold={threshold}',
        str(dst)
    ]
    r = subprocess.run(cmd, capture_output=True)
    return r.returncode == 0 and Path(dst).exists()


def _pad_or_speed_up(src, target, dst,
                     max_speed=4.0,
                     next_start=None, start=0.0):
    """
    FIT CHÍNH XÁC — file dst có duration == target (± 0.026s MP3 frame).

    Nguyên tắc:
      1. Trim silence đầu/cuối
      2. Audio ngắn/vừa slot → PAD silence (KHÔNG speed down)
      3. Audio dài hơn     → SPEED UP vừa đủ (rate chính xác, không snap)
      4. Encode với -t target để CẮT CHÍNH XÁC
      5. VERIFY: đo lại duration, force fix nếu lệch > 0.03s
      6. Repeat verify tối đa 3 lần
    """
    # ── 1. Trim silence ──
    trimmed = str(src).replace('.mp3', '.trim.mp3')
    if _trim_silence(src, trimmed):
        src = Path(trimmed)

    current = _duration(src)
    if current <= 0 or target <= 0:
        subprocess.run(['ffmpeg', '-y', '-i', str(src), str(dst)],
                       capture_output=True, check=False)
        return

    # ── 2. Xử lý ──
    if current <= target:
        # PAD silence chính xác
        cmd = ['ffmpeg', '-y', '-i', str(src),
               '-af', 'apad',
               '-t', f'{target:.4f}',
               '-ar', '44100',
               '-c:a', 'libmp3lame', '-b:a', '128k',
               str(dst)]
    else:
        # Speed up vừa đủ
        rate = current / target
        if rate > max_speed:
            print(f"    ⚠️ Cần {rate:.2f}x (cap {max_speed}x)")
            rate = max_speed
        af = _atempo_chain(rate)
        cmd = ['ffmpeg', '-y', '-i', str(src),
               '-filter:a', af,
               '-t', f'{target:.4f}',
               '-ar', '44100',
               '-c:a', 'libmp3lame', '-b:a', '128k',
               str(dst)]

    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0 or not Path(dst).exists():
        print(f"    ❌ ffmpeg fail: {r.stderr[-200:]}")
        return

    # ── 3. VERIFY + FORCE FIX (tối đa 3 lần) ──
    for attempt in range(3):
        actual = _duration(dst)
        diff = actual - target

        if abs(diff) <= 0.03:
            # Đủ chính xác
            break

        # Force fix
        tmp = str(dst) + f'.fix{attempt}.mp3'
        if diff > 0:
            # Dài hơn → cắt
            fix_cmd = ['ffmpeg', '-y', '-i', str(dst),
                       '-t', f'{target:.4f}',
                       '-ar', '44100',
                       '-c:a', 'libmp3lame', '-b:a', '128k',
                       tmp]
        else:
            # Ngắn hơn → pad
            fix_cmd = ['ffmpeg', '-y', '-i', str(dst),
                       '-af', 'apad',
                       '-t', f'{target:.4f}',
                       '-ar', '44100',
                       '-c:a', 'libmp3lame', '-b:a', '128k',
                       tmp]

        rf = subprocess.run(fix_cmd, capture_output=True, text=True)
        if rf.returncode == 0 and Path(tmp).exists():
            Path(dst).unlink()
            Path(tmp).rename(dst)
        else:
            break

    # Log nếu vẫn lệch
    final_dur = _duration(dst)
    final_diff = final_dur - target
    if abs(final_diff) > 0.05:
        print(f"    ⚠️ Lệch {final_diff:+.3f}s "
              f"(target={target:.3f}s, actual={final_dur:.3f}s)")




def _apply_speed(audio_path, speed):
    """Đổi tốc độ audio với snap tự nhiên."""
    if abs(speed - 1.0) < 0.01:
        return True

    src = Path(audio_path)
    if not src.exists() or src.stat().st_size < 1000:
        return False

    tmp = src.with_suffix('.speed' + src.suffix)
    s = max(0.5, min(4.0, float(speed)))
    # ✅ Snap về tự nhiên
    s = _snap_speed(s)

    try:
        af = _atempo_chain(s)
        r = subprocess.run([
            'ffmpeg', '-y', '-i', str(src),
            '-filter:a', af,
            '-c:a', 'libmp3lame', '-b:a', '128k',
            str(tmp)
        ], capture_output=True, timeout=60)
        if r.returncode == 0 and tmp.exists() and tmp.stat().st_size > 1000:
            src.unlink()
            tmp.rename(src)
            return True
    except Exception as e:
        print(f"  ⚠️ apply_speed fail: {e}")
    if tmp.exists():
        tmp.unlink(missing_ok=True)
    return False


def _check_audio_valid(audio_path, min_size=10000, min_mean_db=-60):
    p = Path(audio_path)
    if not p.exists():
        return False, 'file không tồn tại'
    if p.stat().st_size < min_size:
        return False, f'file quá nhỏ ({p.stat().st_size} bytes)'
    try:
        r = subprocess.run(
            ['ffmpeg', '-i', str(p), '-af', 'volumedetect', '-f', 'null', '-'],
            capture_output=True, text=True, timeout=20)
        m = re.search(r'mean_volume:\s*([-\d.]+)', r.stderr)
        if m:
            mean_db = float(m.group(1))
            if mean_db < min_mean_db:
                return False, f'âm lượng quá nhỏ ({mean_db}dB — im lặng)'
    except Exception:
        pass
    return True, None


def _silence(duration, path):
    duration = max(0.1, float(duration))
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    cmd = ['ffmpeg', '-y', '-f', 'lavfi', '-i', 'anullsrc=r=24000:cl=mono',
           '-t', f'{duration:.3f}', '-c:a', 'libmp3lame', '-q:a', '5', str(path)]
    r = subprocess.run(cmd, capture_output=True, text=True)

    if r.returncode != 0 or not path.exists() or path.stat().st_size < 100:
        print(f"    ⚠️ ffmpeg silence fail, dùng fallback")
        try:
            cmd2 = ['ffmpeg', '-y', '-f', 'lavfi', '-i',
                    f'aevalsrc=0:d={duration:.3f}:s=24000',
                    '-c:a', 'libmp3lame', '-q:a', '9', str(path)]
            r2 = subprocess.run(cmd2, capture_output=True, text=True)
            if r2.returncode == 0 and path.exists():
                return True
        except Exception:
            pass
        return False
    return True


# ============================================================
# DUB SRT — BATCH MODE
# ============================================================
def dub_srt(srt_path, output_dir, lang='vi', voice=None,
            rate="+0%", pitch="+0Hz", progress_cb=None, concurrency=8,
            speed=1.0, batch_size=50):
    """Xử lý SRT lớn: TTS batch → merge → cleanup → batch kế."""
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    if voice is None:
        voice = DEFAULT_VOICE.get(lang, 'vi-VN-HoaiMyNeural')

    with open(srt_path, 'r', encoding='utf-8') as f:
        subs = list(srt.parse(f.read()))
    if not subs:
        raise ValueError("File SRT rỗng")

    lines = []
    for i, sub in enumerate(subs):
        text = sub.content.strip()
        if not text:
            continue
        dur = (sub.end - sub.start).total_seconds()
        if dur <= 0:
            continue
        lines.append({
            'idx': i, 'text': text,
            'start': sub.start.total_seconds(), 'dur': dur,
            'raw': output_dir / f"raw_{i:05d}.mp3",
            'adj': output_dir / f"adj_{i:05d}.mp3",
        })

    for i, ln in enumerate(lines):
        ln['next_start'] = lines[i + 1]['start'] if i + 1 < len(lines) else None

    total = len(lines)
    if total == 0:
        raise RuntimeError("Không có dòng để TTS")

    srt_max_end = max(sub.end.total_seconds() for sub in subs)

    is_hfspace = voice.startswith('hfspace:')
    is_gtts = voice.startswith('gtts:')
    is_capcut = voice.startswith('capcut:')
    is_nghi = voice.startswith('nghi:')
    is_sequential = is_hfspace or is_gtts or is_capcut or is_nghi

    if is_hfspace:
        mode = f"HF Space tuần tự ({parse_hfspace_voice(voice)})"
    elif is_gtts:
        mode = "gTTS tuần tự"
    elif is_capcut:
        mode = "CapCut tuần tự"
    elif is_nghi:
        mode = "NGHI-TTS (Piper local)"
    else:
        mode = f"Edge-TTS parallel ×{concurrency}"

    n_batches = (total + batch_size - 1) // batch_size
    print(f"🎙️ TTS {total} dòng ({mode}) — {voice}")
    if n_batches > 1:
        print(f"⚙️  Batch mode: {batch_size} dòng/lần × {n_batches} batch")

    batch_files = []

    for b_idx in range(n_batches):
        b_start = b_idx * batch_size
        b_end = min(b_start + batch_size, total)
        batch_lines = lines[b_start:b_end]

        print(f"\n📦 Batch {b_idx + 1}/{n_batches} (dòng {b_start + 1}–{b_end})")

        if not is_sequential:
            # ── Edge-TTS parallel ──
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                edge_rate = rate
                if speed != 1.0:
                    pct = int((speed - 1.0) * 100)
                    edge_rate = f"{pct:+d}%"

                for s in range(0, len(batch_lines), concurrency):
                    sub_batch = batch_lines[s:s + concurrency]
                    items = [(l['text'], l['raw']) for l in sub_batch]
                    results = loop.run_until_complete(
                        _edge_tts_batch(items, voice, edge_rate, pitch))

                    for line, (status, msg) in zip(sub_batch, results):
                        if status == 'ok':
                            raw_path = Path(line['raw'])
                            if raw_path.exists() and abs(speed - 1.0) > 0.01:
                                _apply_speed(raw_path, speed)
                            _pad_or_speed_up(
                                line['raw'], line['dur'], line['adj'],
                                next_start=line.get('next_start'),
                                start=line['start'])
                        else:
                            print(f"  ⚠️ Dòng {line['idx'] + 1}: {msg}")
                            _silence(line['dur'], line['adj'])
            finally:
                loop.close()
        else:
            # ── Sequential (HF/CapCut/NGHI/gTTS) ──
            for i, line in enumerate(batch_lines):
                status, msg = synthesize_line_smart(
                    line['text'], voice, line['raw'],
                    rate=rate, pitch=pitch, speed=speed)

                raw_path = Path(line['raw'])
                if status == 'ok' and raw_path.exists() and abs(speed - 1.0) > 0.01:
                    _apply_speed(raw_path, speed)

                adj_path = Path(line['adj'])
                if status == 'ok' and raw_path.exists():
                    _pad_or_speed_up(
                        line['raw'], line['dur'], line['adj'],
                        next_start=line.get('next_start'),
                        start=line['start'])

                if not adj_path.exists() or adj_path.stat().st_size < 100:
                    if status != 'ok':
                        print(f"  ⚠️ Dòng {line['idx'] + 1}: {msg}")
                    _silence(line['dur'], line['adj'])

                if progress_cb:
                    try:
                        progress_cb(b_start + i + 1, total)
                    except Exception:
                        pass

        if progress_cb:
            try:
                progress_cb(b_end, total)
            except Exception:
                pass
        print(f"  🎙️ {b_end}/{total}")

        # ── Merge batch ──
        batch_segments = [(l['start'], l['dur'], l['adj']) for l in batch_lines]
        batch_out = output_dir / f"batch_{b_idx:04d}.mp3"
        _merge_segments(batch_segments, batch_out, srt_max_end=srt_max_end)
        batch_files.append(batch_out)

        # ── Cleanup raw (GIỮ adj để tính SRT sync) ──
        for l in batch_lines:
            Path(l['raw']).unlink(missing_ok=True)
            Path(str(l['raw']).replace('.mp3', '.trim.mp3')).unlink(missing_ok=True)
        print(f"  🧹 Đã dọn raw batch {b_idx + 1} (giữ adj)")

    # ── Merge tất cả batch ──
    print(f"\n🔗 Merge {len(batch_files)} batch → file cuối...")
    final = output_dir / "dubbed_full.mp3"
    _merge_batch_files(batch_files, final, srt_max_end)

    for bf in batch_files:
        bf.unlink(missing_ok=True)

    # ✅ Tạo SRT sync từ adj files (trước khi xóa adj)
    try:
        synced_srt = write_synced_srt(srt_path, output_dir)
        print(f"📄 SRT sync: {synced_srt}")
    except Exception as e:
        print(f"⚠️  Không tạo được SRT sync: {e}")

    # Xóa adj sau khi đã tạo SRT sync
    for l in lines:
        Path(l['adj']).unlink(missing_ok=True)

    print(f"✅ Hoàn tất: {final}")
    return final


# ============================================================
# MERGE — N segment → 1 file
# ============================================================
def _merge_sequential(items, output_path, pause=0.10):
    """
    Xếp các file adj LIÊN TIẾP (không dùng SRT timestamp).
    Có pause giữa các câu để không bị dính chùm.
    """
    if not items:
        raise RuntimeError("Không có item")

    total_dur = sum(d for d, _ in items) + pause * (len(items) - 1) + 0.5
    inputs = []
    filter_parts = []
    cursor = 0.0

    for idx, (dur, af) in enumerate(items):
        inputs.extend(['-i', str(af)])
        # ✅ Dùng suffix 's' cho giây
        d_ms = int(cursor * 1000)
        filter_parts.append(f'[{idx}:a]adelay={d_ms}|{d_ms}[a{idx}]')
        cursor += dur + pause

    mix = ''.join(f'[a{i}]' for i in range(len(items)))
    filter_parts.append(f'{mix}amix=inputs={len(items)}:duration=longest:normalize=0[out]')
    fc = ';'.join(filter_parts)

    cmd = ['ffmpeg', '-y'] + inputs + [
        '-filter_complex', fc, '-map', '[out]',
        '-t', f'{total_dur:.4f}',
        '-ar', '44100',
        '-c:a', 'libmp3lame', '-b:a', '128k',
        str(output_path)
    ]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError(f"Merge seq fail: {r.stderr[-300:]}")


def _merge_segments(segments, output_path, srt_max_end=None):
    """
    Merge CHÍNH XÁC — dùng adelay theo start, nhưng log verify.
    Mỗi file adj phải có duration == slot để không gap/overlap.
    """
    valid = []
    for start, dur, af in segments:
        af_path = Path(af)
        if af_path.exists() and af_path.stat().st_size > 100:
            actual = _duration(af_path)
            # Cảnh báo nếu lệch slot
            diff = actual - dur
            if abs(diff) > 0.05:
                print(f"  ⚠️ {af_path.name}: "
                      f"actual={actual:.3f}s vs slot={dur:.3f}s "
                      f"({diff:+.3f}s)")
            valid.append((start, dur, actual, af))
        else:
            print(f"  ⚠️ Skip: {af_path.name}")

    if not valid:
        raise RuntimeError("Không có segment hợp lệ!")

    audio_end = max(s[0] + s[2] for s in valid)
    if srt_max_end and srt_max_end > 0:
        total_dur = min(audio_end, srt_max_end) + 0.5
    else:
        total_dur = audio_end + 0.5

    segments = [(s[0], s[1], s[3]) for s in valid]
    print(f"  🔗 Merge {len(segments)} segments (total {total_dur:.1f}s)")

    BATCH = 30
    if len(segments) <= BATCH:
        _merge_batch(segments, output_path, total_dur)
        return

    # > 30 segments → chia batch
    temps = []
    for i in range(0, len(segments), BATCH):
        bf = output_path.parent / f"tmp_{output_path.stem}_{i//BATCH:03d}.mp3"
        _merge_batch(segments[i:i+BATCH], bf, total_dur)
        temps.append(bf)

    if len(temps) == 1:
        temps[0].rename(output_path)
    else:
        inputs = []
        for f in temps:
            inputs.extend(['-i', str(f)])
        mix = ''.join(f'[{i}:a]' for i in range(len(temps)))
        fc = f'{mix}amix=inputs={len(temps)}:duration=longest:normalize=0[out]'
        cmd = ['ffmpeg', '-y'] + inputs + [
            '-filter_complex', fc, '-map', '[out]',
            '-t', f'{total_dur:.4f}',
            '-ar', '44100',
            '-c:a', 'libmp3lame', '-b:a', '128k',
            str(output_path)]
        subprocess.run(cmd, capture_output=True, check=True)

    for f in temps:
        f.unlink(missing_ok=True)


def _merge_batch(segments, output_path, total_dur):
    """Merge 1 batch — adelay với độ chính xác 0.1ms."""
    inputs = []
    fp = []
    for idx, (start, dur, af) in enumerate(segments):
        inputs.extend(['-i', str(af)])
        # ✅ Dùng microsecond thay vì millisecond để chính xác hơn
        # ✅ Dùng suffix 's' (seconds) để chính xác — ffmpeg default là ms
        d_ms = int(start * 1000)
        fp.append(f'[{idx}:a]adelay={d_ms}|{d_ms}[a{idx}]')
    istr = ';'.join(fp)
    mix = ''.join(f'[a{i}]' for i in range(len(segments)))
    fc = f'{istr};{mix}amix=inputs={len(segments)}:duration=longest:normalize=0[out]'
    cmd = ['ffmpeg', '-y'] + inputs + [
        '-filter_complex', fc, '-map', '[out]',
        '-t', f'{total_dur:.4f}',
        '-ar', '44100',
        '-c:a', 'libmp3lame', '-b:a', '128k',
        str(output_path)]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError(f"Merge batch lỗi: {r.stderr[-500:]}")


def _merge_batch_files(batch_files, output_path, srt_max_end=None):
    """
    Nối các batch file — dùng AMIX (overlap), KHÔNG sequential.
    """
    if not batch_files:
        raise RuntimeError("Không có batch")
    if len(batch_files) == 1:
        batch_files[0].rename(output_path)
        return

    durations = [_duration(b) for b in batch_files]
    total_dur = max(durations)
    if srt_max_end and srt_max_end > 0:
        total_dur = min(total_dur, srt_max_end) + 0.5
    else:
        total_dur = total_dur + 0.5

    print(f"  📊 Batch durations: min={min(durations):.1f}s, "
          f"max={max(durations):.1f}s, total={total_dur:.1f}s")

    BATCH = 30
    if len(batch_files) <= BATCH:
        inputs = []
        for f in batch_files:
            inputs.extend(['-i', str(f)])
        mix = ''.join(f'[{i}:a]' for i in range(len(batch_files)))
        fc = f'{mix}amix=inputs={len(batch_files)}:duration=longest:normalize=0[out]'
        cmd = ['ffmpeg', '-y'] + inputs + [
            '-filter_complex', fc, '-map', '[out]',
            '-t', f'{total_dur:.4f}',
            '-ar', '44100',
            '-c:a', 'libmp3lame', '-b:a', '128k',
            str(output_path)
        ]
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode != 0:
            raise RuntimeError(f"Merge batch fail: {r.stderr[-500:]}")
        return

    # > 30 batch → merge theo tầng
    print(f"  🔀 > 30 batch → merge theo tầng...")
    level = 0
    current = batch_files[:]
    while len(current) > 1:
        level += 1
        next_level = []
        for i in range(0, len(current), BATCH):
            group = current[i:i + BATCH]
            if len(group) == 1:
                next_level.append(group[0])
                continue
            out = output_path.parent / f"lvl{level}_{i//BATCH:03d}.mp3"
            inputs = []
            for f in group:
                inputs.extend(['-i', str(f)])
            mix = ''.join(f'[{j}:a]' for j in range(len(group)))
            fc = f'{mix}amix=inputs={len(group)}:duration=longest:normalize=0[out]'
            cmd = ['ffmpeg', '-y'] + inputs + [
                '-filter_complex', fc, '-map', '[out]',
                '-t', f'{total_dur:.4f}',
                '-ar', '44100',
                '-c:a', 'libmp3lame', '-b:a', '128k',
                str(out)
            ]
            r = subprocess.run(cmd, capture_output=True, text=True)
            if r.returncode != 0:
                raise RuntimeError(f"Merge level {level} fail: {r.stderr[-500:]}")
            next_level.append(out)

        if level > 1:
            for f in current:
                f.unlink(missing_ok=True)
        current = next_level
        print(f"    Tầng {level}: {len(current)} file")

    current[0].rename(output_path)



def merge_dub_with_video(video_path, audio_path, output_path,
                          mix_original=False, original_volume=0.15):
    if mix_original:
        cmd = ['ffmpeg', '-y', '-i', str(video_path), '-i', str(audio_path),
               '-filter_complex',
               f'[0:a]volume={original_volume}[o];[1:a]volume=1.0[d];'
               f'[o][d]amix=inputs=2:duration=first:normalize=0[a]',
               '-map', '0:v', '-map', '[a]', '-c:v', 'copy',
               '-c:a', 'aac', '-b:a', '192k', '-shortest', str(output_path)]
    else:
        cmd = ['ffmpeg', '-y', '-i', str(video_path), '-i', str(audio_path),
               '-map', '0:v', '-map', '1:a', '-c:v', 'copy',
               '-c:a', 'aac', '-b:a', '192k', '-shortest', str(output_path)]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError(f"Ghép video lỗi: {r.stderr[-500:]}")
    return output_path