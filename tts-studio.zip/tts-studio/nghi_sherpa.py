"""nghi_sherpa.py — NGHI-TTS parallel pool. Hỗ trợ 10k+ dòng."""
import os, queue, shutil, struct, subprocess, urllib.request, wave
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from threading import Lock

NGHI_VOICES = [
    ('banmai','Ban Mai','banmai.onnx'),
    ('ngocngan','Ngoc Ngan','ngocngan3701.onnx'),
    ('maiphuong','Mai Phuong','maiphuong.onnx'),
    ('minhthu','Minh Thu','minhthu.onnx'),
    ('mytam','My Tam','mytam2794.onnx'),
    ('mytam2','My Tam 2','mytam2.onnx'),
    ('ngochuyen','Ngoc Huyen','ngochuyen.onnx'),
    ('ngochuyennew','Ngoc Huyen moi','ngochuyennew.onnx'),
    ('phuongtrang','Phuong Trang','phuongtrang.onnx'),
    ('thanhphuong2','Thanh Phuong','thanhphuong2.onnx'),
    ('vietthao','Viet Thao','vietthao3886.onnx'),
    ('yannew','Yan New','yannew.onnx'),
    ('lacphi','Lac Phi','lacphi.onnx'),
    ('chieuthanh','Chieu Thanh','chieuthanh.onnx'),
    ('calmwoman','Calm Woman','calmwoman3688.onnx'),
    ('adam1','Adam','adam1.onnx'),
    ('manhdung','Manh Dung','manhdung.onnx'),
    ('minhkhang','Minh Khang','minhkhang.onnx'),
    ('minhquang','Minh Quang','minhquang.onnx'),
    ('deepman','Deep Man','deepman3909.onnx'),
    ('duyoryx','Duy Oryx','duyoryx3175.onnx'),
    ('taian2','Tai An 2','taian2.onnx'),
    ('taian4','Tai An 4','taian4.onnx'),
    ('tranthanh','Tran Thanh','tranthanh3870.onnx'),
    ('thientam','Thien Tam','thientam.onnx'),
]

NGHI_VOICE_MAP = {s: l for s, l, _ in NGHI_VOICES}
NGHI_FILE_MAP = {s: f for s, _, f in NGHI_VOICES}

CACHE_DIR = Path.home() / ".cache" / "nghi_sherpa"
CACHE_DIR.mkdir(parents=True, exist_ok=True)
HF_BASE = "https://huggingface.co/doof-ferb/nghitts-copy/resolve/main/sherpa-onnx"
ESPEAK_URL = ("https://github.com/k2-fsa/sherpa-onnx/releases/download/"
              "tts-models/espeak-ng-data.tar.bz2")

_CPU_COUNT = os.cpu_count() or 4
POOL_SIZE = int(os.environ.get("NGHI_POOL_SIZE",
                str(max(1, min(4, _CPU_COUNT // 2)))))
_THREADS_PER_INSTANCE = int(os.environ.get("NGHI_THREADS", "1"))

_pools = {}
_pool_lock = Lock()


def _download(url, dest, min_size=1000):
    dest = Path(dest)
    if dest.exists() and dest.stat().st_size > min_size:
        return True
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=600) as r:
            tmp = dest.with_suffix(dest.suffix + ".tmp")
            with open(tmp, "wb") as f:
                shutil.copyfileobj(r, f)
            tmp.rename(dest)
        return dest.exists() and dest.stat().st_size > min_size
    except Exception as e:
        print("  [download] " + dest.name + ": " + str(e))
        return False


def _ensure_files():
    tokens = CACHE_DIR / "tokens.txt"
    if not _download(HF_BASE + "/tokens.txt", tokens, min_size=100):
        return False
    espeak_dir = CACHE_DIR / "espeak-ng-data"
    if not espeak_dir.exists() or not (espeak_dir / "phontab").exists():
        import tarfile
        tar_path = CACHE_DIR / "espeak-ng-data.tar.bz2"
        if not _download(ESPEAK_URL, tar_path, min_size=100000):
            return False
        try:
            with tarfile.open(tar_path, "r:bz2") as tf:
                tf.extractall(CACHE_DIR)
            tar_path.unlink()
        except Exception as e:
            print("  [extract] " + str(e))
            return False
    return True


def _create_instance(model_path):
    try:
        import sherpa_onnx as so
        return so.OfflineTts(config=so.OfflineTtsConfig(
            model=so.OfflineTtsModelConfig(
                vits=so.OfflineTtsVitsModelConfig(
                    model=str(model_path),
                    tokens=str(CACHE_DIR / "tokens.txt"),
                    data_dir=str(CACHE_DIR / "espeak-ng-data"),
                ),
                num_threads=_THREADS_PER_INSTANCE,
            ),
        ))
    except Exception as e:
        print("  [create] " + str(e))
        return None


def get_pool(slug):
    if slug in _pools:
        return _pools[slug]
    with _pool_lock:
        if slug in _pools:
            return _pools[slug]
        if not _ensure_files():
            return None
        onnx = NGHI_FILE_MAP.get(slug)
        if not onnx:
            print("  [pool] khong co giong " + slug)
            return None
        model_path = CACHE_DIR / onnx
        if not _download(HF_BASE + "/" + onnx, model_path, min_size=1_000_000):
            return None
        print("[POOL] Load " + str(POOL_SIZE) + " instances x "
              + str(_THREADS_PER_INSTANCE) + " threads -- " + slug)
        q = queue.Queue()
        instances = []
        for i in range(POOL_SIZE):
            inst = _create_instance(model_path)
            if inst is not None:
                instances.append(inst)
                q.put(inst)
        if not instances:
            return None
        _pools[slug] = (instances, q)
        print("  [OK] Pool san sang: " + str(len(instances)) + " instances")
        return _pools[slug]


def synthesize_one(text, output_file, slug, speed=1.0, timeout=120):
    text = (text or "").strip()
    if not text:
        return ("error", "Text rong")
    pool = get_pool(slug)
    if pool is None:
        return ("error", "Khong load duoc giong " + slug)
    instances, q = pool
    tts = q.get()
    out = Path(output_file)
    out.parent.mkdir(parents=True, exist_ok=True)
    tmp_wav = out.with_suffix(".tmp.wav")
    try:
        s = max(0.5, min(2.0, float(speed)))
        audio = tts.generate(text[:2000], sid=0, speed=s)
        if not audio or not audio.samples or len(audio.samples) == 0:
            return ("error", "Sherpa audio rong")
        import array
        n = len(audio.samples)
        buf = array.array('h', bytes(2 * n))
        for i, x in enumerate(audio.samples):
            v = x if -1.0 <= x <= 1.0 else max(-1.0, min(1.0, x))
            buf[i] = int(v * 32767)
        with wave.open(str(tmp_wav), "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(audio.sample_rate)
            wf.writeframes(buf.tobytes())
        r = subprocess.run(
            ["ffmpeg", "-y", "-i", str(tmp_wav),
             "-ar", "44100", "-ac", "2",
             "-c:a", "libmp3lame", "-b:a", "128k", str(out)],
            capture_output=True, timeout=60)
        if r.returncode != 0 or not out.exists() or out.stat().st_size < 1000:
            return ("error", "Convert MP3 fail")
        return ("ok", str(out))
    except Exception as e:
        return ("error", "Sherpa: " + str(e))
    finally:
        try:
            tmp_wav.unlink(missing_ok=True)
        except Exception:
            pass
        q.put(tts)


def synthesize_batch(items, slug, speed=1.0, max_workers=None, progress_cb=None):
    if not items:
        return []
    if max_workers is None:
        max_workers = POOL_SIZE
    max_workers = min(max_workers, POOL_SIZE)
    n = len(items)
    results = [None] * n
    counter = [0]
    counter_lock = Lock()

    def worker(idx, text, out):
        try:
            status, msg = synthesize_one(text, out, slug, speed)
        except Exception as e:
            status, msg = "error", str(e)
        results[idx] = (status, msg)
        with counter_lock:
            counter[0] += 1
            done = counter[0]
        if progress_cb:
            try:
                progress_cb(done, n)
            except Exception:
                pass

    with ThreadPoolExecutor(max_workers=max_workers,
                            thread_name_prefix="nghi") as ex:
        futures = [ex.submit(worker, i, t, o)
                   for i, (t, o) in enumerate(items)]
        for f in futures:
            f.result()
    return results


def synthesize(text, output_file, slug, timeout=120, speed=1.0):
    return synthesize_one(text, output_file, slug, speed=speed)


def available():
    try:
        import sherpa_onnx
        import soundfile
        return True
    except ImportError:
        return False


def cleanup_pools():
    global _pools
    with _pool_lock:
        _pools.clear()
        import gc
        gc.collect()


def get_config():
    return {
        'cpu_count': _CPU_COUNT,
        'pool_size': POOL_SIZE,
        'threads_per_instance': _THREADS_PER_INSTANCE,
        'loaded_pools': list(_pools.keys()),
    }
