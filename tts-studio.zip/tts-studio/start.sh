#!/data/data/com.termux/files/usr/bin/bash
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"

pkill -f "python.*tts-studio/app.py" 2>/dev/null
sleep 1

termux-wake-lock 2>/dev/null

PORT="${TTS_PORT:-5001}"
HOST="${TTS_HOST:-0.0.0.0}"

echo "Khoi dong TTS Studio..."
TTS_PORT="$PORT" TTS_HOST="$HOST" nohup python -u app.py > tts.log 2>&1 &
echo $! > tts.pid
sleep 4

if kill -0 "$(cat tts.pid)" 2>/dev/null; then
    LAN_IP=$(ifconfig 2>/dev/null | grep 'inet ' | grep -v 127.0.0.1 | grep -E '192|10\.|172\.' | head -1 | awk '{print $2}')
    echo ""
    echo "================================================"
    echo "  TTS Studio dang chay"
    echo "  Local:   http://127.0.0.1:$PORT"
    [ -n "$LAN_IP" ] && echo "  LAN:     http://$LAN_IP:$PORT"
    echo "  Log:     tail -f $DIR/tts.log"
    echo "  Stop:    ./stop.sh"
    echo "================================================"
else
    echo "Loi! Xem log:"
    cat tts.log
    exit 1
fi
