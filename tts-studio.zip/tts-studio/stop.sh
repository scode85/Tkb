#!/data/data/com.termux/files/usr/bin/bash
cd "$(dirname "${BASH_SOURCE[0]}")"
if [ -f tts.pid ]; then
    PID=$(cat tts.pid)
    kill "$PID" 2>/dev/null && echo "Da dung PID $PID"
    rm -f tts.pid
fi
pkill -f "python.*tts-studio/app.py" 2>/dev/null
termux-wake-unlock 2>/dev/null
echo "OK"
